🌟 REPORTE MENSUAL — MARCH 2026
--------------------------------------
💰 Ingresos:  $14,435,000
💸 Gastos:    $1,517,500
⚖️ Balance:   $12,917,500 🏆

📊 Detalle por categorías:
• Alimentación: $659,500 (43.5%)
• Servicios: $320,000 (21.1%)
• Transporte: $248,000 (16.3%)
• Otros: $200,000 (13.2%)
• Gimnasio / Deporte: $90,000 (5.9%)

Reporte generado automáticamente el 24/03/2026