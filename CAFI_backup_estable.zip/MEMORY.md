# MEMORY.md

Registro de patrones aprendidos sobre los hábitos de Manuel:
- Gastaste 80.000 en Servicios
- Usaste Uber como Transporte
- Tu ingreso principal es de 120.000
- Gastaste 80.000 en Servicios
- Usaste Uber como Transporte
- Ingresaste 120.000
- Gastaste 80.000 en Servicios
- Usaste Uber como Transporte
- Ingresaste 120.000
- Gastaste 25.000 en Alimentación
- Gastaste 80.000 en Servicios
- Usaste Uber como Transporte
- Ingresaste 120.000
